
package View;

import processing.core.PApplet;

public class Main {
	
	PApplet app;
	int alto;
	int ancho;
	int click;
	
	public void draw() {
		
	}
	public void setup() {
		
	}
	public void settings() {
		
	}
	
	public void mouseReleased(){
		
	}
}

