
package View;

import processing.core.PApplet;

public class Main {
	
	PApplet app;
	
	public void draw() {
		
	}
	public void setup() {
		
	}
	public void settings() {
		
	}
	
	public void mouseReleased(){
		
	}
}

