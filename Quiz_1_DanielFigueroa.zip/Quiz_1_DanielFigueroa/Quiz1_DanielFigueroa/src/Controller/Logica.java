package Controller;

public class Logica {

	
}
