package Model;

import processing.core.PApplet;

public class Figura2 extends Figuras {
	
	PApplet app;
}
