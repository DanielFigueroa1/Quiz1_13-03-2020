package Model;

public class Figura2 extends Figuras {

}
