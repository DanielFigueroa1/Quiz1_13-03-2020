package Model;

import processing.core.PApplet;

public class Figura3 extends Figuras {
	
	PApplet app;

}
