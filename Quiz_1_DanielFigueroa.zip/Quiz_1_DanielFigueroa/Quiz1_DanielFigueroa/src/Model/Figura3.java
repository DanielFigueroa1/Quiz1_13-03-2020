package Model;

public class Figura3 extends Figuras {

}
