package Model;

import processing.core.PApplet;

public class Figuras {

	PApplet app;
	public int figura;
	public int tam;
	public int posX;
	public int posY;
	public int direccion;
	
	public int getPosX() {
		return posX;
	}
	public void setPosX(int posX) {
		this.posX = posX;
	}
	public int getPosY() {
		return posY;
	}
	public void setPosY(int posY) {
		this.posY = posY;
	}
	
	
}
