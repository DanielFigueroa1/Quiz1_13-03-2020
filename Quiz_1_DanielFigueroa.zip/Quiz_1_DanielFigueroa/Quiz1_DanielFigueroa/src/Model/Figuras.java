package Model;

import processing.core.PApplet;

public class Figuras {

	PApplet app;
	public int figura;
	public int tam;
	public int posX;
	public int posY;
	public int direccion;
	
	
}
