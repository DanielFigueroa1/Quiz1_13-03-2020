package Model;

public class Figura1 extends Figuras {

}
