package Model;

import processing.core.PApplet;

public class Figura1 extends Figuras {
	
	PApplet app;

}
